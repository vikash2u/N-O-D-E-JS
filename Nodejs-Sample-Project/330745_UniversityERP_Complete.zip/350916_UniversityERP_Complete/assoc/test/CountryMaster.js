process.env.NODE_ENV = 'test';

var mongoose = require("mongoose");
var Country = require('../server/models/master/Country');

var chai = require('chai');
var chaiHttp = require('chai-http');
var server = require('../server');
var should = chai.should();
chai.use(chaiHttp);

//list
describe('/GET countries', () => {
  it('it should GET all the countries', (done) => {
	chai.request(server)
		.get('/countries')
		.end((err, res) => {
			should.equal(err, null); 
			res.should.have.status(200);
			res.body.data.should.be.a('array');
			res.body.data.length.should.be.eql(9);
		  done();
		});


  });
});
//active list
describe('/GET activeCountries', () => {
  it('it should GET all the active countries', (done) => {
	chai.request(server)
		.get('/activeCountries')
		.end((err, res) => {
			should.equal(err, null); 
			res.should.have.status(200);
			res.body.data.should.be.a('array');
			res.body.data.length.should.be.eql(6);
		  done();
		});
  });
});
