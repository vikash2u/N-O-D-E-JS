process.env.NODE_ENV = 'test';

var mongoose = require("mongoose");
var City = require('../server/models/master/City');

var chai = require('chai');
var chaiHttp = require('chai-http');
var server = require('../server');
var should = chai.should();
chai.use(chaiHttp);

//getByState >> /state/:id/cities
describe('/getByState', () => {
  it('it should get all city for a state', (done) => {
	   let stateid =  '596605dddefe2613e4cd99d5';
	   chai.request(server)
		.get('/state/' + stateid + '/cities')
		.end((err, res) => {
			should.equal(err, null); 
			res.should.have.status(200);
			res.body.data.should.be.a('array');
			res.body.data.length.should.be.eql(2);
		  done();
		});
  });
});
