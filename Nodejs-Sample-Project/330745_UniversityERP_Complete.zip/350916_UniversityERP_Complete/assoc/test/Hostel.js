process.env.NODE_ENV = 'test';

var mongoose = require("mongoose");
var hostel = require('../server/models/Hostel');

var chai = require('chai');
var chaiHttp = require('chai-http');
var server = require('../server');
var should = chai.should();
chai.use(chaiHttp);

//activeListByCollege >> /college/:id/activeHostels
describe('/activeListByCollege', () => {
  it('it should get all active hostel for a college', (done) => {
	   let collegeid =  '596703c49512e412b84ae4c6';
	   chai.request(server)
		.get('/college/' + collegeid + '/activeHostels')
		.end((err, res) => {
			should.equal(err, null); 
			res.should.have.status(200);
			res.body.data.should.be.a('array');
			res.body.data.length.should.be.eql(2);
		  done();
		});
  });
});
