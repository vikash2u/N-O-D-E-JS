process.env.NODE_ENV = 'test';

var mongoose = require("mongoose");
var college = require('../server/models/College');

var chai = require('chai');
var chaiHttp = require('chai-http');
var server = require('../server');
var should = chai.should();
chai.use(chaiHttp);

//getByCountry >> /country/:id/colleges
describe('/getByCountry', () => {
  it('it should get all city for a state', (done) => {
	   let countryid =  '5835a37e93ec8c0d7cadd1d9';
	   chai.request(server)
		.get('/country/' + countryid + '/colleges')
		.end((err, res) => {
			should.equal(err, null); 
			res.should.have.status(200);
			res.body.data.should.be.a('array');
			res.body.data.length.should.be.eql(2);
		  done();
		});
  });
});
