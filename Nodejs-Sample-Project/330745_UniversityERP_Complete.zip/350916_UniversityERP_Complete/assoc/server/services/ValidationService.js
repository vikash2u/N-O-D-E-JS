/*
// Created by Academy on 20/10/16
// Create ValidationService with a single function validationErrors
// Capture the mongodb errors and return them as Understandable messages
// For example if a required field is not included, then capture the error
// return <field name> is Required
*/
exports.validationErrors = function (err) {
    var errors = {};
    console.log(err);
    if (err) {
        switch (err.name) {            
            case 'ValidationError':            
                for (field in err.errors) {
                    switch (err.errors[field].name) {
                        case 'ValidatorError':                            
                            if(err.errors[field].kind =="required")
                            {                                                           
                                errors[field] = [err.errors[field].path] + ' is Required';
                            }
                            break;                                                
                        case 'CastError':
                            errors[field] = [err.errors[field].path] + ' must be a ' + err.errors[field].kind;                            
                            break;
                    }
                }
                break;            
            case 'MongoError':    
                var regex = /index\:\ (?:.*\.)?\$?(?:([_a-z0-9]*)(?:_\d*)|([_a-z0-9]*))\s*dup key/i;      
                var match =  err.message.match(regex); 
                var field = match[1] || match[2];                                      
                errors[field] = field + ' already exists';
                break;
        }
    }
    return errors;
};