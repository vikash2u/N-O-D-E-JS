/*
// Created by Academy on 20/10/16
// Controller for Managing Colleges
*/
var HttpStatus = require('http-status');
var College = require('../models/College');
var Validation = require('../services/ValidationService'); 
//Export the save method to save a College
//Check if the College already exists
//throw a College already exists error
//If not then create the College
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
    var today = new Date().toJSON().slice(0,10);
	var newCollege = College({
		name: req.body.name,
		addressLine1: req.body.addressLine1,
		addressLine2: req.body.addressLine2,
		city: req.body.city,
		state: req.body.state,
		country: req.body.country,
	    activeStatus: true,
        createdOn: today,
        updatedOn: today
	});
	 newCollege.save(function(saveErr,saveCollege){        
            if (saveErr) {                           
                res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(saveErr)
            });            
            return;
        }
        res.status(HttpStatus.OK).json({
            status: 'success',
            code: HttpStatus.OK,
            data: saveCollege,
            error: ''
        });
    });	
	/*College.find({name : newCollege.name}, function (err, docs) {
        if (docs.length){
            console.log('College already exists');
        }else{
			newCollege.save(function(err) {
				if (err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK
					});
				}   
			});
        }
    });*/
};

//Export the list method to return a list of all Colleges
exports.list = function(req, res){
    College.find({}).populate('city state').
	exec(function (err, colleges) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: colleges
            });
		}   
  });
};

//Export the activeList method to return a list of all Active Colleges
exports.activeList = function(req, res){
    College.find({activeStatus: true}).populate('city state').
	exec(function (err, colleges) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: colleges
            });
		}   
  });
};

//Export the getByCountry method to list 
//all active Colleges for a given Country
//The Country id is passed as id in the request parameters
exports.getByCountry = function(req, res){
	console.log('getByCountry :: ' + req.params.id);
   College.find({activeStatus: true,country: req.params.id}).populate('city state').
	exec(function (err, colleges) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: colleges
            });
		}   
  });
   
};

//Export the get method to return
//a College object given the id in the request parameters
exports.get = function(req, res){
	College.find({_id: req.params.id}).populate('city state country').
	exec(function (err, college) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: college[0]
            });
		}   
  });
  
};

//Export the update method
//Find the College by id passed in the request parameters 
//and update it with the College object in the request body
//Throw an error
//If the College name already exists
//If the College is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
    
	College.findById(req.params.id, function(err, college) {

        if (err) {
            res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
                status: 'failure',
                code: HttpStatus.INTERNAL_SERVER_ERROR,
                data: '',
                error: 'College not found'
            });

            return;
        }
        if (college == null) {
            res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: 'College not found'
            });
            return;
        }
        college.name = req.body.name;
        college.addressLine1 = req.body.addressLine1;
        college.addressLine2=req.body.addressLine2;
        college.city=req.body.city;
        college.state=req.body.state;
        college.country=req.body.country;
        college.activeStatus = true;
        college.updatedOn = Date.now();       
        college.save(function(saveErr, saveCollege) {
            if (saveErr) {
                res.status(HttpStatus.BAD_REQUEST).json({
                    status: 'failure',
                    code: HttpStatus.BAD_REQUEST,
                    data: '',
                    error: Validation.validationErrors(saveErr)
                });
                return;
            }
            res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: saveCollege,
                error: ''
            });
        });
    });
};

//Export the activate method
//Find the College by the id request parameter
//Update the College activeStatus to true
//Throw an error
//If the College is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    College.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('College not exists');
        }	
		else{
			College.findByIdAndUpdate(req.params.id, { activeStatus: true }, function(err, college1) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: college1
					});
				}  
	        });
		}
	});
};

//Export the deactivate method
//Find the College by the id request parameter
//Update the College activeStatus to false
//Throw an error
//If the College is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    College.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('College not exists');
        }	
		else{
			College.findByIdAndUpdate(req.params.id, { activeStatus: false }, function(err, college1) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: college1
					});
				}  
	        });
		}
	});
};