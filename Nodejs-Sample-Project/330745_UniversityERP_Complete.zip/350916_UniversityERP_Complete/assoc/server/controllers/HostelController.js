/*
// Created by Academy on 20/10/16
// Controller for Managing Hostels
*/

var HttpStatus = require('http-status');
var College = require('../models/College');
var Hostel = require('../models/Hostel');

var mongoose = require('mongoose');
var ObjectId = mongoose.Types.ObjectId;
var Validation = require('../services/ValidationService'); 

//Export the save method to save a Hostel
//Check if the Hostel already exists for the given College
//throw a Hostel already exists error
//If not then create the Hostel for the Given College
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
    var today = new Date().toJSON().slice(0,10);
	var newHostel = Hostel({
		name: req.body.name,
		college: req.body.college,
	    activeStatus: true,
        createdOn: today,
        updatedOn: today
	});
	newHostel.save(function(saveErr,saveHostel){        
            if (saveErr) {                           
                res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(saveErr)
            });            
            return;
        }
        res.status(HttpStatus.OK).json({
            status: 'success',
            code: HttpStatus.OK,
            data: saveHostel,
            error: ''
        });
    });	
};

//Export the list method to return a list of all Hostels
exports.list = function(req, res){
    Hostel.find({}).populate('college').
	exec(function (err, hostels) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: hostels
            });
		}   
  });
};

//Export the getByCollege method to list 
//all Hostels for a given College
//The College id is passed as id in the request parameters
exports.getByCollege = function(req, res){
   Hostel.find({college: req.params.id}).populate('college').
	exec(function (err, hostels) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: hostels
            });
		}   
  }); 
};

//Export the activeListByCollege method to list 
//all active Hostels for a given College
//The College id is passed as id in the request parameters
exports.activeListByCollege = function(req, res){
	Hostel.find({activeStatus: true,college: req.params.id}).populate('college').
	exec(function (err, hostels) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: hostels
            });
		}   
  }); 
}

//Export the get method to return
//a Hostel object given the id in the request parameters
exports.get = function(req, res){
    Hostel.find({_id: req.params.id}).populate('college').
	exec(function (err, hostels) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: hostels
            });
		}   
  });
};

//Export the update method
//Find the Hostel by id passed in the request parameters 
//and update it with the Hostel object in the request body
//Throw an error
//If the Hostel name already exists
//If the Hostel is not found
////Use the validationErrors service for any validation errors
exports.update = function(req, res){
    var today = new Date().toJSON().slice(0,10);
    Hostel.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Hostel not exists');
			 res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: 'Hostel not found'
            });
            return;
        }	
		else{
			Hostel.findByIdAndUpdate(req.params.id, { name: req.body.name, updatedOn: today }, function(err, hostel) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: Validation.validationErrors(saveErr)
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: hostel
					});
				}  
	        });
		}
	});
};

//Export the activate method
//Find the Hostel by the id request parameter
//Update the Hostel activeStatus to true
//Throw an error
//If the Hostel is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    Hostel.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Hostel not exists');
        }	
		else{
			Hostel.findByIdAndUpdate(req.params.id, { activeStatus: true}, function(err, hostel) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: hostel
					});
				}  
	        });
		}
	});
};

//Export the deactivate method
//Find the Hostel by the id request parameter
//Update the Hostel activeStatus to false
//Throw an error
//If the Hostel is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    Hostel.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Hostel not exists');
        }	
		else{
			Hostel.findByIdAndUpdate(req.params.id, { activeStatus: false}, function(err, hostel) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: hostel
					});
				}  
	        });
		}
	});
};