/*
// Created by Academy on 20/10/16
// Controller for Managing the Country Master
*/

var Country = require('../../models/master/Country');
var HttpStatus = require('http-status');
var Validation = require('../../services/ValidationService'); 
//Export the save method to save a Country
//Check if the country already exists 
//throw a country already exists error
//If not then create the country
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
	var today = new Date().toJSON().slice(0,10);
	var newCountry = Country({
		name: req.body.name,
	    activeStatus: true,
        createdOn: today,
        updatedOn: today
	});
    newCountry.save(function(saveErr) {
        if (saveErr) {
            res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(saveErr)
            });
            return;
        }
        res.status(HttpStatus.OK).json({
			status: 'success',
			code: HttpStatus.OK
		});
    });
	/*Country.find({name : newCountry.name}, function (err, docs) {
        if (docs.length){
            console.log('Country exists already');
        }else{
			newCountry.save(function(err) {
				if (err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK
					});
				}   
			});
        }
    });*/
};

//Export the list method to return a list of all Countries
exports.list = function(req, res){
  	Country.find({}, function(err, country) {
        if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: country
            });
		}   
	});
};

//Export the activeList method to list all active Countries
exports.activeList = function(req, res){
   	 Country.find({activeStatus: true}, function(err, country) 
	 {
		if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: country
            });
		}   
	 });

};

//Export the update method
//Find the Country by id passed in the request parameters 
//and update it with the country object in the request body
//Throw an error
//If the country name already exists
//If the country is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
	Country.findByIdAndUpdate(req.params.id, { name: req.body.name }, function(err, country) {
	  if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
	        res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: country
            });
		}  
	});
};

//Export the activate method
//Find the Country by the id in request parameter
//Update the Country's activeStatus to true
//Throw an error
//If the country is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
	Country.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Country not exists');
        }	
		else{
			Country.findByIdAndUpdate(req.params.id, { activeStatus: true }, function(err, country) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: country
					});
				}  
	        });
		}
	});
	
};

//Export the deactivate method
//Find the Country by the id in request parameter
//Update the Country's activeStatus to false
//Throw an error
//If the country is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    Country.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Country not exists');
        }	
		else{
			Country.findByIdAndUpdate(req.params.id, { activeStatus: false }, function(err, country) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: country
					});
				}  
	        });
		}
	});
};