/*
// Created by Academy on 20/10/16
// Controller for managing the State Master
*/

var State = require('../../models/master/State');
var Country = require('../../models/master/Country');
var City = require('../../models/master/City');
var HttpStatus = require('http-status');
var mongoose = require('mongoose');
var ObjectId = mongoose.Types.ObjectId;
var Validation = require('../../services/ValidationService'); 

//Export the save method to save a State
//Check if the State already exists 
//throw a State already exists error
//If not then create the State
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
 	var today = new Date().toJSON().slice(0,10);
	var newState = State({
		name: req.body.name,
		country: req.body.country,
	    activeStatus: true,
        createdOn: today,
        updatedOn: today
	});
	newState.save(function(err) {
        if (err) {
            res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(err)
            });
            return;
        }
        res.status(HttpStatus.OK).json({
			status: 'success',
			code: HttpStatus.OK
		});
    });		
	/*State.find({name : newState.name}, function (err, docs) {
        if (docs.length){
            console.log('State already exists');
        }else{
			newState.save(function(err) {
				if (err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK
					});
				}   
			});
        }
    });*/
};

//Export the list method to return a list of all States
exports.list = function(req, res){
	State.find({}).populate('country').
	exec(function (err, states) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: states
            });
		}   
  });
};

//Export the activeList method to list all active States
exports.activeList = function(req, res){
   	State.find({activeStatus: true}).populate('country').
	exec(function (err, states) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: states
            });
		}   
  });
};

//Export the getByCountry method to list 
//all States for a given Country
//The Country id is passed as id in the request parameters
exports.getByCountry = function(req, res){
  	State.find({country: req.params.id}).populate('country').
	exec(function (err, states) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: states
            });
		}   
  });
};

//Export the update method
//Find the State by id passed in the request parameters 
//and update it with the State object in the request body
//Throw an error
//If the State name already exists
//If the State is not found
////Use the validationErrors service for any validation errors
exports.update = function(req, res){
	State.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('State not exists');
        }	
		else{
			State.findByIdAndUpdate(req.params.id, { name: req.body.name, country: req.body.country }, function(err, state) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: state
					});
				}  
	        });
		}
	});
};

//Export the activate method
//Find the State by the id request parameter
//Update the State activeStatus to true
//Throw an error
//If the State is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
   State.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('State not exists');
        }	
		else{
			State.findByIdAndUpdate(req.params.id, { activeStatus: true }, function(err, state) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: state
					});
				}  
	        });
		}
	});
};

//Export the deactivate method
//Find the State by the id request parameter
//Update the State activeStatus to false
//Throw an error
//If the State is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
    State.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('State not exists');
        }	
		else{
			State.findByIdAndUpdate(req.params.id, { activeStatus: false }, function(err, state) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: state
					});
				}  
	        });
		}
	});
};