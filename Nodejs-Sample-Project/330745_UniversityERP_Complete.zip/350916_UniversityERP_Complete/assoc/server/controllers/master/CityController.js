/*
// Created by Academy on 20/10/16
// Controller for Managing City Master
*/

var HttpStatus = require('http-status');
var State = require('../../models/master/State');
var City = require('../../models/master/City');
var Validation = require('../../services/ValidationService'); 

//Export the save method to save a City
//Check if the city already exists 
//throw a city already exists error
//If not then create the city
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
		
    var today = new Date().toJSON().slice(0,10);
	var newCity = City({
		name: req.body.name,
		state: req.body.state,
	    activeStatus: true,
        createdOn: today,
        updatedOn: today
	});
	newCity.save(function(err) {
        if (err) {
            res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(err)
            });
            return;
        }
        res.status(HttpStatus.OK).json({
			status: 'success',
			code: HttpStatus.OK
		});
    });	
	/*City.find({name : newCity.name}, function (err, docs) {
        if (docs.length){
            console.log('City already exists');
        }else{
			newCity.save(function(err) {
				if (err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK
					});
				}   
			});
        }
    });*/
};

//Export the list method to return a list of all Cities
exports.list = function(req, res){
   City.find({}).populate('state').
	exec(function (err, cities) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			console.log(cities);
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: cities
            });
		}   
  });
};


//Export the activeList method to list all active Cities
exports.activeList = function(req, res){
   
	City.find({activeStatus: true}).populate('state').
	exec(function (err, cities) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: cities
            });
		}   
  });
};

//Export the getByState method to list 
//all active Cities for a given State
//The state id is passed as id in the request parameters
exports.getByState = function(req, res){
   	City.find({state: req.params.id}).populate('state').
	exec(function (err, cities) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: cities
            });
		}   
  });
}

//Export the get method to return
//a City object given the id in the request parameters
exports.get = function(req, res){
    City.find({_id: req.params.id}).populate('state').
	exec(function (err, cities) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: cities
            });
		}   
  });
};

//Export the update method
//Find the city by id passed in the request parameters 
//and update it with the city object in the request body
//Throw an error
//If the city name already exists
//If the city is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
	var today = new Date().toJSON().slice(0,10);
    City.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('City not exists');
        }	
		else{
			City.findByIdAndUpdate(req.params.id, { name: req.body.name, state: req.body.state, updatedOn: today }, function(err, city) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					console.log('Update - sucessful');
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: city
					});
				}  
	        });
		}
	});
};

//Export the activate method
//Find the city by the id request parameter
//Update the city activeStatus to true
//Throw an error
//If the city is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
	console.log('city activate');
   var today = new Date().toJSON().slice(0,10);
    City.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('City not exists');
        }	
		else{
			City.findByIdAndUpdate(req.params.id, { activeStatus: true}, function(err, city) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: city
					});
				}  
	        });
		}
	});
};

//Export the deactivate method
//Find the city by the id request parameter
//Update the city activeStatus to false
//Throw an error
//If the city is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
	console.log('city deactivate');
    var today = new Date().toJSON().slice(0,10);
    City.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('City not exists');
        }	
		else{
			console.log('else deactivate');
			City.findByIdAndUpdate(req.params.id, { activeStatus: false}, function(err, city1) {
				if(err) {
					console.log('error deactivate');
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
					console.log('success deactivate');
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: city1
					});
				}  
	        });
		}
	});
};