/*
// Created by Academy on 20/10/16
// Controller for Managing Students
*/
var Student = require('../models/Student');
var College = require('../models/College');
var Hostel = require('../models/Hostel');

var HttpStatus = require('http-status');
var mongoose = require('mongoose');
var ObjectId = mongoose.Types.ObjectId;
var Validation = require('../services/ValidationService'); 
//Export the save method to save a Student
//Check if the Roll No already exists 
//throw a Roll no already exists error
//If not then create the Student
//Use the validationErrors service for any validation errors
exports.save = function(req, res){
	var today = new Date().toJSON().slice(0,10);
	var newStudent = Student({
		name: req.body.name,
		rollNo:req.body.rollNo,
		dob:req.body.dob,
		email:req.body.email,
		mobileNumber:req.body.mobileNumber,
		year:req.body.year,
		yearOfJoining:req.body.yearOfJoining,
		college: req.params.collegeid,
		hostel: req.body.hostel,
	    activeStatus: true,
        createdOn: today,
        updatedOn: today
	});
			
	newStudent.save(function(saveErr,saveStudent){        
            if (saveErr) {                           
                res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: Validation.validationErrors(saveErr)
            });            
            return;
        }
        res.status(HttpStatus.OK).json({
            status: 'success',
            code: HttpStatus.OK,
            data: saveStudent,
            error: ''
        });
    });	
};

//Export the get method to return
//a Student object given the id in the request parameters
//If the student is not found
//Throw a student not found error
exports.get = function(req, res){
   	Student.find({_id: req.params.id}).populate('hostel').
	exec(function (err, student) {
		if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			console.log('student : ' + student)
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: student[0]
            });
		}   
	 });
	
	
};

//Export the list method to return a list of all Students
exports.list = function(req, res){
    Student.find({}).populate('college hostel').
	exec(function (err, students) {
    if (err) {
			res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                error: err
            });
		}
        else{
			res.status(HttpStatus.OK).json({
                status: 'success',
                code: HttpStatus.OK,
                data: students
            });
		}   
  });
};

//Export the getByCollege method to list 
//all active Students for a given College
//The College id is passed as id in the request parameters
exports.getByCollege = function(req,res){
    Student.find({college: req.params.id}).populate('college hostel').
		exec(function (err, students) {
		if (err) {
				res.status(HttpStatus.BAD_REQUEST).json({
					status: 'failure',
					code: HttpStatus.BAD_REQUEST,
					error: err
				});
			}
			else{
				res.status(HttpStatus.OK).json({
					status: 'success',
					code: HttpStatus.OK,
					data: students
				});
			}   
	  });
};

//Export the update method
//Find the Student by id passed in the request parameters 
//and update it with the Student object in the request body
//Throw an error
//If the Student Roll No already exists
//If the Roll No is not found
//Use the validationErrors service for any validation errors
exports.update = function(req, res){
    var today = new Date().toJSON().slice(0,10);
    Student.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Student not exists');
			 res.status(HttpStatus.BAD_REQUEST).json({
                status: 'failure',
                code: HttpStatus.BAD_REQUEST,
                data: '',
                error: 'Student not found'
            });
            
        }	
		else{
			Student.findByIdAndUpdate(req.params.id, { 
			        name: req.body.name,
					dob:req.body.dob,
					email:req.body.email,
					mobileNumber:req.body.mobileNumber,
					year:req.body.year,
					yearOfJoining:req.body.yearOfJoining,
					college: req.body.college,
					hostel: req.body.hostel,
					updatedOn: today }, function(err, student) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: Validation.validationErrors(saveErr)
					});
				}
				else{
					res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: student
					});
				}  
	        });
		}
	});
};

//Export the activate method
//Find the Student by the id request parameter
//Update the Student activeStatus to true
//Throw an error
//If the Student is not found
//Use the validationErrors service for any validation errors
exports.activate = function(req, res){
    Student.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Student not exists');
        }	
		else{
			Student.findByIdAndUpdate(req.params.id, { activeStatus: true}, function(err, student) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: student
					});
				}  
	        });
		}
	});
};

//Export the deactivate method
//Find the Student by the id request parameter
//Update the Student activeStatus to false
//Throw an error
//If the Student is not found
//Use the validationErrors service for any validation errors
exports.deactivate = function(req, res){
     Student.find({_id : req.params.id}, function (err, docs) {
        if (!docs.length){
            console.log('Student not exists');
        }	
		else{
			Student.findByIdAndUpdate(req.params.id, { activeStatus: false}, function(err, student) {
				if(err) {
					res.status(HttpStatus.BAD_REQUEST).json({
						status: 'failure',
						code: HttpStatus.BAD_REQUEST,
						error: err
					});
				}
				else{
				    res.status(HttpStatus.OK).json({
						status: 'success',
						code: HttpStatus.OK,
						data: student
					});
				}  
	        });
		}
	});
};
