
'use strict';

const router = require('express').Router();

require('./user')(router);

module.exports = router;