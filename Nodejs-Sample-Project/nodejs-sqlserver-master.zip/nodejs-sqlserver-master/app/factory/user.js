'use strict';

module.exports = class User {
	constructor(user) {
		this.id   = user.id,
		this.name = user.name,
		this.datebirth = user.datebirth
	}
}