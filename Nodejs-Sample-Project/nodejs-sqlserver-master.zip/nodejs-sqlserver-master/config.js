const config = {
	database: {
		userName: 'nodejs',
		password: 'nodejs123',
		server: 'localhost',
		options: {
			instanceName: 'devweb2012',
			database: 'nodejs-sqlserver'
		}
	}
};

module.exports = config;