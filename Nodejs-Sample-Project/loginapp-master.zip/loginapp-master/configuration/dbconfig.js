var mysql  = require('mysql')
 
/**
 * This middleware provides a consistent API 
 * for MySQL connections during request/response life cycle
 */ 
//var myConnection  = require('express-myconnection')
/**
 * Store database credentials in a separate config.js file
 * Load the file/module and its values
 */ 
var config = require('../configuration/config')
var dbconfig =  mysql.createConnection ({
    host:      config.database.host,
    user:       config.database.user,
    password: config.database.password,
    port:       config.database.port, 
    database: config.database.db,
    multipleStatements: true
});
dbconfig.connect((err) => {
   if(!err) {
     console.log("MySql Database is connected on the port : ",config.database.port);  
 } else {
     console.log("Error connecting database ... \n\n");  
 }
});
dbconfig.serverport =config.server.port; 
module.exports = dbconfig