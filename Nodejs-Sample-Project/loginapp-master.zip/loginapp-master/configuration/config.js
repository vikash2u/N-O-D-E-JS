var config = {
    database: {
        host:      'localhost',     // database host
        user:       'suvankar',         // your database username
        password: 'password',         // your database password
        port:       3306,         // default MySQL port
      database:   'mysqldb'         // your database name
    },
    server: {
        host: 'localhost',
        port: '3000'
    }
}
 
module.exports = config