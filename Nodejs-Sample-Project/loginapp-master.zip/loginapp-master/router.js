'use strict';
var router = require('express').Router();
const inheit = require('./app.js');
 //Get all employees
router.get('/employees', (req, res) => {
   inheit.mysqlConnection.query('SELECT * FROM mysqldb.employees', (err, rows, fields) => {
        if (!err)
        {
        var jsonData =JSON.stringify(rows, null, 2);
        //inheit.locals.empdata =JSON.stringify(rows, null, 2);
       // res.end(JSON.stringify(jsonData, null, 2));
        res.end(jsonData);
        console.log("Before Firing the event for kafka producer.");
        //Fire the 'scream' event:
           inheit.eventEmitter.emit('KafkaProducer');
            console.log("After Firing the event for kafka producer.");
        }
        else
        {
            console.log("Error Selecting : %s ",err);
        }
    })
});

//Get an employees
router.get('/api/employees/GET/:id', (req, res) => {
    inheit.mysqlConnection.query('SELECT * FROM mysqldb.employees WHERE id = ?', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    })
});

//Insert an employees
router.post('/api/employees/POST', (req, res) => {
    let emp = req.body;
    var sql = "SET @id = ?;SET @name = ?;SET @address1 = ?;SET @address2 = ?;SET @city = ?;SET @state = ?;SET @postalcode = ?;SET @country = ?;SET @email = ?;SET @phone = ?; \
    CALL mysqldb.employeeAddorEdit(@id,@name,@address1,@address2,@city,@state,@postalcode,@country,@email,@phone);";
    inheit.mysqlConnection.query(sql, [0, emp.name, emp.address1, emp.address2,emp.city,emp.state,emp.postalcode,emp.country,emp.email,emp.phone], (err, rows, fields) => {
        if (!err)
           /* rows.forEach(element => {
                if(element.constructor == Array)
                console.log('element');
                res.send('Inserted employee id : '+ "xxxxx");
            });*/
                res.send('Inserted employee id : '+ emp.name);
        else
            console.log(err);
    })
});

//Update an employees
router.put('/api/employees/PUT', (req, res) => {
    let emp = req.body;
   var sql = "SET @id = ?;SET @name = ?;SET @address1 = ?;SET @address2 = ?;SET @city = ?;SET @state = ?;SET @postalcode = ?;SET @country = ?;SET @email = ?;SET @phone = ?; \
    CALL mysqldb.employeeAddorEdit(@id,@name,@address1,@address2,@city,@state,@postalcode,@country,@email,@phone);";
    inheit.mysqlConnection.query(sql, [0, emp.name, emp.address1, emp.address2,emp.city,emp.state,emp.postalcode,emp.country,emp.email,emp.phone], (err, rows, fields) => {
        if (!err)
            res.send('Updated successfully');
        else
            console.log(err);
    })
});

//Delete an employees
router.delete('/api/employees/DELETE/:id', (req, res) => {
    inheit.mysqlConnection.query('DELETE FROM mysqldb.employees WHERE id = ?', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send('Deleted successfully.');
        else
            console.log(err);
    })
});


//export this router to use in our app.js
module.exports = router;