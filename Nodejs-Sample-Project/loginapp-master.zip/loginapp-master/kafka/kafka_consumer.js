
var kafka = require('kafka-node'),
    Consumer = kafka.Consumer,
    client = new kafka.Client('localhost:2181'),
    consumer = new Consumer(
        client,
        [
            { topic: 'javainuse-topic', offset: 26, partition: 0 }
        ],
        {
            // Consumer group id, default `kafka-node-group`
            groupId: 'kafka-node-group',
            // Optional consumer id, defaults to groupId + uuid
            id: 'my-consumer-id',
            // Auto commit config
            autoCommit: false,
            autoCommitIntervalMs: 5000,
            // The max wait time is the maximum amount of time in milliseconds to block waiting if insufficient data is available at the time the request is issued, default 100ms
            fetchMaxWaitMs: 1000,
            // This is the minimum number of bytes of messages that must be available to give a response, default 1 byte
            fetchMinBytes: 1,
            // The maximum bytes to include in the message set for this partition. This helps bound the size of the response.
            fetchMaxBytes: 1024 * 1024,
            // If set true, consumer will fetch message from the given offset in the payloads
            fromOffset: 'latest', //"latest" "false"
            // If set to 'buffer', values will be returned as raw buffer objects.
            encoding: 'utf8',
            keyEncoding: 'utf8'
        }
    );


var offset = new kafka.Offset(client);  
var topic = 'javainuse-topic';


consumer.on('ready', function() {
    console.log("Consumer is ready");
});

consumer.on('message', function (message) {
    var parsedData = JSON.parse(message.value);
    var JSONString = JSON.stringify(parsedData);
    console.log("Received message from kaka consumer :- ",JSONString);

    
});

consumer.on('error', function (err) {
    console.log('Error:',err);
})

/*
* If consumer get `offsetOutOfRange` event, fetch data from the smallest(oldest) offset
*/
consumer.on('offsetOutOfRange', function (topic) {
  topic.maxNum = 2;
  offset.fetch([topic], function (err, offsets) {
    if (err) {
      return console.error(err);
    }
    var min = Math.min.apply(null, offsets[topic.topic][topic.partition]);
    consumer.setOffset(topic.topic, topic.partition, min);
  });
});

consumer.on('SIGINT', function () {
    consumer.close(true, function () {
        process.exit();
    });
});
//export this router to use in our app.js
//module.exports = consumer;
 


