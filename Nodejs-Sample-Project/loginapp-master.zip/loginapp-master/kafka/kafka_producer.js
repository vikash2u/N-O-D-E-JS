var routerkafkapub = require('express').Router();
var kafka = require('kafka-node');

//var logger = require('../log/logger.js');
//Used for encryptedString and decryptedString
const Cryptr = require('cryptr');
const cryptr = new Cryptr('myTotalySecretKey');

var Producer = kafka.Producer,
    client = new kafka.Client(),
    producer = new Producer(client);

producer.on('ready', function() {
    console.log("Producer is ready");
});

// For this demo we just log producer errors to the console.
producer.on('error', function (err) {
       console.log("Error in initialization");
});

routerkafkapub.get('/',function(req,res){
    res.json({greeting:'kafka Producer'})
});
routerkafkapub.post('/sendMsg',function(req,res){
    var sentMessage = JSON.stringify(req.body.message);
    //console.log("1.", req.body.topic);
    //console.log("2" , req.body.message);
    //console.log("3", sentMessage);
    const encryptedString = cryptr.encrypt(sentMessage);
    const decryptedString = cryptr.decrypt(encryptedString);
 
   // console.log(encryptedString); // 74ad21741ffbf4973d4c3aa1db413bc77fc89e0a44d6d0
   // console.log(decryptedString); // req.body.message
console.log("Producer sends data");
    payloads = [
        { topic: req.body.topic, messages:sentMessage , partition: 0 }
    ];
    producer.send(payloads, function (err, data) {
            res.json(data);
    }); 
    //logger.info('Data successfully produce to kafka log.');
});

//export this router to use in our app.js
module.exports.routerkafkapub = routerkafkapub;

